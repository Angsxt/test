# ELYTRA OS

**Codename:** AURORA · **Initial target:** Ubuntu 26.04 LTS, x86-64  
**Desktop strategy:** KDE Plasma base + ELYTRA's own QML desktop experience.

ELYTRA is a personal Linux distribution project. This first repository is a **developer prototype**, not yet a bootable ISO. It contains the first ELYTRA Home dashboard, the project configuration, and scripts to prepare a development machine and build the UI.

## Current milestone

- [x] Project skeleton and design tokens
- [x] ELYTRA Home dashboard prototype (Qt 6 / QML), version 0.2.0 with working navigation and section pages
- [x] Development dependency installer
- [x] Local run/build scripts
- [x] Initial package manifest
- [ ] KDE Plasma integration (autostart, theme, shortcuts)
- [ ] ELYTRA Center backend (D-Bus + Polkit)
- [ ] Store / updater
- [ ] Reproducible Ubuntu image build
- [ ] Hardware validation on ASUS TUF + desktop PCs

## Important architecture decision

The TikTok reference appears to show a highly customized Linux desktop configuration with a sidebar, dashboard, Waybar/bar layout, Hyprland, Rofi, themes, cursors and notifications. ELYTRA will take inspiration from that workflow and visual language, but the selected platform remains **KDE Plasma**. We will implement ELYTRA's own dashboard and controls with Qt Quick/QML, then integrate them into Plasma. We are not switching the window manager to Hyprland in this first implementation.

## Requirements

- Ubuntu 26.04 LTS x86-64 recommended for target testing
- For UI development: Qt 6.5 or newer (CMake requires it). Ubuntu 24.04 ships an older Qt 6 release, so Qt 6.5+ has to be installed separately there, or use Ubuntu 26.04 LTS.
- Git, CMake, Ninja, C++ compiler, Qt 6 Quick and Controls development packages

## Quick start

```bash
git clone <your-repository-url> elytra-os
cd elytra-os
./scripts/install-dev-deps.sh
./scripts/run-dev.sh
```

Build without running:

```bash
./scripts/build-ui.sh
```

Build output is written to `build/`.

## Run on another Linux distribution

The dependency script targets Ubuntu/Debian package names. On other distributions install Qt 6 Quick, Qt 6 Quick Controls, CMake, Ninja and a C++ compiler using that distribution's package manager.

## Project layout

```text
ELYTRA-OS/
├── apps/elytra-home/       # First QML dashboard application
├── branding/               # Colors, identity and wallpaper guidance
├── config/                 # Desktop and package configuration
├── docs/                   # Architecture and roadmap
├── packaging/              # Debian package skeleton
└── scripts/                # Local developer scripts
```

## Safety

The prototype is a normal user application. It does not run commands as root, change firewall rules, manage packages, or execute AI-generated shell commands. Those features will be implemented later behind explicit authorization (Polkit) and user confirmation.
