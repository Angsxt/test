# ELYTRA technical architecture

## Target

- Ubuntu 26.04 LTS
- x86-64 only
- ASUS TUF Gaming A17 (AMD + NVIDIA) and standard Intel/AMD desktop PCs
- Personal distribution first; possible public release later

## Layers

1. **Ubuntu base:** kernel, systemd, APT, firmware and hardware enablement.
2. **KDE Plasma:** session, KWin compositor, Wayland, Plasma panels and settings.
3. **ELYTRA shell experience:** Qt 6 / QML apps and Plasma integration.
4. **System services:** small privileged helpers exposed over D-Bus; Polkit authorization for privileged operations.
5. **Applications:** Flatpak and APT initially; optional Snap compatibility only where needed.

## First applications

| Component | Initial implementation | Later responsibility |
|---|---|---|
| ELYTRA Home | Qt Quick/QML dashboard | Home, widgets, launcher entry points |
| ELYTRA Center | Planned Qt Quick + Python service | Hardware, users, updates, settings |
| ELYTRA Store | Planned app UI | APT/Flatpak app management |
| ELYTRA Connect | Planned app UI | Network, SSH, server status |
| ELYTRA AI | Planned client abstraction | Local/cloud models; confirmation gate |
| ELYTRA Dev | Package profile | VS Code, Git, Docker and SDKs |
| ELYTRA Gaming | Package/profile integration | Steam, Proton, Vulkan and telemetry |

## Desktop integration

- Keep KDE Plasma and KWin as the initial session.
- Build the ELYTRA Home UI as a regular Qt Quick app first.
- Later add Plasma wallpaper/theme, panel layout, shortcuts, autostart and lock-screen styling.
- Avoid replacing KWin or Plasma components until the KDE-based experience is stable.

## Security boundaries

- UI processes run unprivileged.
- No shell command execution from QML.
- Privileged operations are implemented in a narrow helper/service.
- D-Bus API methods validate all arguments.
- Polkit authorizes each privileged operation.
- AI output is treated as untrusted; no automatic execution.
- Package installation requires explicit user confirmation.
- Docker group membership is treated as root-equivalent access.

## Image strategy

The current milestone builds and tests the UI on an installed Ubuntu system. A reproducible live/installable image is a separate milestone because Ubuntu image composition, bootloader, kernel/initramfs, signed repositories and installer integration must be tested together. Do not label the current UI build as an OS ISO.
