# ELYTRA roadmap

## Milestone 0 — Repository and visual prototype
- Project skeleton, QML dashboard, design tokens, local build scripts.
- Acceptance: `./scripts/run-dev.sh` opens ELYTRA Home.

## Milestone 1 — KDE integration
- Plasma theme, wallpaper, icon/cursor theme, panel layout.
- ELYTRA Home autostart option and keyboard shortcut.
- Acceptance: fresh KDE session loads the ELYTRA experience without breaking standard Plasma controls.

## Milestone 2 — ELYTRA Center
- Hardware inventory and read-only monitoring first.
- Settings via supported system APIs.
- Privileged operations through D-Bus + Polkit.
- Acceptance: no root-running GUI and no unapproved privileged changes.

## Milestone 3 — Store and updates
- Flatpak catalog first, then APT integration.
- Show source, publisher, permissions and update state.
- Acceptance: install/remove/update operations require explicit confirmation and report failures.

## Milestone 4 — Dev, Connect and Virtualization
- Git, VS Code, Docker, SSH, KVM/QEMU/libvirt.
- Acceptance: verify on ASUS TUF and one Intel/AMD desktop.

## Milestone 5 — Gaming and AI
- Steam/Proton/Vulkan, GPU detection and optional local/cloud AI.
- AI remains advisory until user confirms a proposed action.

## Milestone 6 — Image and recovery
- Reproducible Ubuntu-based image, installer, signed repository and rollback/recovery plan.
- Acceptance: clean install, update, recovery and hardware test matrix.
