import QtQuick
import QtQuick.Controls
import QtQuick.Layouts

ApplicationWindow {
    id: window
    width: 1280
    height: 820
    minimumWidth: 900
    minimumHeight: 620
    visible: true
    title: "ELYTRA Home"
    color: "#080D18"

    property string activePage: "Home"
    property date now: new Date()

    Timer {
        interval: 30000
        running: true
        repeat: true
        onTriggered: window.now = new Date()
    }

    component Card: Rectangle {
        radius: 18
        color: "#D916263A"
        border.color: "#253D5B"
        border.width: 1
    }

    readonly property var navItems: [
        { key: "Home", icon: "⌂" },
        { key: "Dashboard", icon: "▦" },
        { key: "Applications", icon: "▤" },
        { key: "System Center", icon: "⚙" },
        { key: "Connect", icon: "⌘" },
        { key: "Developer", icon: "⌁" },
        { key: "ELYTRA AI", icon: "✧" },
        { key: "Gaming", icon: "◇" }
    ]

    readonly property var homeTiles: [
        { icon: "▣", title: "Development", desc: "VS Code · Git · Docker", cta: "Open developer", target: "Developer" },
        { icon: "⌘", title: "Server & Network", desc: "SSH · Network tools · Status", cta: "Manage connections", target: "Connect" },
        { icon: "◇", title: "Gaming", desc: "Steam · Proton · Performance", cta: "Open game hub", target: "Gaming" },
        { icon: "▤", title: "Virtualization", desc: "KVM · QEMU · Machines", cta: "Manage VMs", target: "Developer" },
        { icon: "✧", title: "ELYTRA AI", desc: "Local and cloud assistant", cta: "Ask assistant", target: "ELYTRA AI" },
        { icon: "⬡", title: "System Center", desc: "Hardware · Updates · Security", cta: "System settings", target: "System Center" }
    ]

    readonly property var pages: ({
        "Dashboard": {
            subtitle: "System overview. Live hardware data arrives with Milestone 2.",
            items: [
                { icon: "▣", title: "Hardware", desc: "CPU, RAM, GPU and temperatures", status: "Planned" },
                { icon: "◷", title: "Power", desc: "Battery, power profile and runtime", status: "Planned" },
                { icon: "⇅", title: "Network", desc: "Connections, IP and DNS", status: "Planned" },
                { icon: "✧", title: "Updates", desc: "Security updates and version state", status: "Planned" }
            ]
        },
        "Applications": {
            subtitle: "Store and app management. Milestone 3.",
            items: [
                { icon: "▤", title: "ELYTRA Store", desc: "Browse and install Flatpak and APT apps", status: "Planned" },
                { icon: "▦", title: "Installed apps", desc: "Overview, removal and permissions", status: "Planned" },
                { icon: "⇩", title: "App updates", desc: "Pending updates with explicit confirmation", status: "Planned" },
                { icon: "⚿", title: "Sources", desc: "Flathub, Ubuntu repositories, ELYTRA repository", status: "Planned" }
            ]
        },
        "System Center": {
            subtitle: "Settings, updates and security. Milestone 2.",
            items: [
                { icon: "▣", title: "Hardware", desc: "Device inventory and drivers", status: "Planned" },
                { icon: "◉", title: "Users", desc: "Accounts without permanent admin rights", status: "Planned" },
                { icon: "⇩", title: "Updates", desc: "Stable and beta channels", status: "Planned" },
                { icon: "⛨", title: "Security", desc: "Firewall (UFW), disk encryption, Polkit", status: "Planned" },
                { icon: "◷", title: "Power", desc: "Energy profiles", status: "Planned" },
                { icon: "◐", title: "Design", desc: "ELYTRA Aurora theme and accent colour", status: "Planned" }
            ]
        },
        "Connect": {
            subtitle: "Network, SSH and servers. Milestone 4.",
            items: [
                { icon: "⇅", title: "Network overview", desc: "Interfaces, IP addresses and DNS", status: "Planned" },
                { icon: "⌁", title: "SSH connections", desc: "Saved hosts and keys", status: "Planned" },
                { icon: "▦", title: "Server status", desc: "Reachability and load of saved hosts", status: "Planned" },
                { icon: "▤", title: "Containers", desc: "Docker containers and Compose stacks", status: "Planned" },
                { icon: "⛨", title: "Firewall", desc: "Rules managed through UFW", status: "Planned" },
                { icon: "✦", title: "Diagnostics", desc: "Ping, traceroute and port checks", status: "Planned" }
            ]
        },
        "Developer": {
            subtitle: "Development profile. Milestone 4.",
            items: [
                { icon: "▣", title: "VS Code", desc: "Editor with a ready-made profile", status: "Planned" },
                { icon: "⌁", title: "Git & GitHub", desc: "Repositories and credentials", status: "Planned" },
                { icon: "▤", title: "Docker & Compose", desc: "Containers and multi-container stacks", status: "Planned" },
                { icon: "⌘", title: "Languages", desc: "Python, Node.js and .NET", status: "Planned" },
                { icon: "▦", title: "Virtual machines", desc: "KVM, QEMU and libvirt", status: "Planned" },
                { icon: "◇", title: "Databases", desc: "Local database tools", status: "Planned" }
            ]
        },
        "ELYTRA AI": {
            subtitle: "Assistant for questions, logs and scripts. Milestone 6. The assistant only suggests actions; it never runs them automatically.",
            items: [
                { icon: "✧", title: "Ask questions", desc: "Answers about ELYTRA and Linux", status: "Planned" },
                { icon: "⌁", title: "Explain commands", desc: "What a terminal command does before it runs", status: "Planned" },
                { icon: "▦", title: "Analyse logs", desc: "Find the cause of errors in system logs", status: "Planned" },
                { icon: "◉", title: "Local model", desc: "Optional, via Ollama", status: "Planned" },
                { icon: "⇅", title: "Cloud provider", desc: "Optional, with a clear data notice", status: "Planned" },
                { icon: "⛨", title: "Confirmation gate", desc: "Every change needs explicit approval", status: "Planned" }
            ]
        },
        "Gaming": {
            subtitle: "Gaming hub. Milestone 5. Proprietary drivers are installed only after hardware detection and your consent.",
            items: [
                { icon: "◇", title: "Steam & Proton", desc: "Game library and compatibility layer", status: "Planned" },
                { icon: "▤", title: "Lutris", desc: "Games from other stores", status: "Planned" },
                { icon: "⌘", title: "Controllers", desc: "Controller detection and mapping", status: "Planned" },
                { icon: "▦", title: "GPU monitoring", desc: "Load, temperature and VRAM", status: "Planned" },
                { icon: "◷", title: "Performance profiles", desc: "GameMode and MangoHud presets", status: "Planned" },
                { icon: "✧", title: "Vulkan", desc: "Graphics driver check", status: "Planned" }
            ]
        }
    })

    readonly property var currentPage: pages[activePage] !== undefined ? pages[activePage] : ({ subtitle: "", items: [] })

    function greeting(d) {
        const h = d.getHours();
        if (h < 5) return "Good night.";
        if (h < 12) return "Good morning.";
        if (h < 18) return "Good afternoon.";
        return "Good evening.";
    }

    RowLayout {
        anchors.fill: parent
        anchors.margins: 18
        spacing: 16

        // Navigation rail
        Card {
            Layout.preferredWidth: 238
            Layout.fillHeight: true
            color: "#F20D1727"

            ColumnLayout {
                anchors.fill: parent
                anchors.margins: 18
                spacing: 12

                RowLayout {
                    spacing: 10
                    Rectangle {
                        width: 38; height: 38; radius: 12
                        gradient: Gradient {
                            GradientStop { position: 0.0; color: "#16C9F5" }
                            GradientStop { position: 1.0; color: "#2675FF" }
                        }
                        Text {
                            anchors.centerIn: parent
                            text: "E"
                            color: "#06111D"
                            font.pixelSize: 23
                            font.bold: true
                        }
                    }
                    ColumnLayout {
                        spacing: 0
                        Label { text: "ELYTRA"; color: "#F1F5FA"; font.bold: true; font.pixelSize: 17 }
                        Label { text: "AURORA · 0.2"; color: "#8293A8"; font.pixelSize: 10 }
                    }
                }

                Rectangle { Layout.fillWidth: true; height: 1; color: "#263B55" }

                Label { text: "WORKSPACE"; color: "#6F879F"; font.pixelSize: 10; font.bold: true }

                Repeater {
                    model: window.navItems
                    delegate: Rectangle {
                        required property var modelData
                        readonly property bool active: window.activePage === modelData.key

                        Layout.fillWidth: true
                        implicitHeight: 43
                        radius: 11
                        color: active ? "#253B566B" : (navMouse.containsMouse ? "#18283A" : "transparent")
                        border.color: active ? "#315E7B" : "transparent"

                        Label {
                            x: 14
                            anchors.verticalCenter: parent.verticalCenter
                            text: modelData.icon + "   " + modelData.key
                            color: parent.active ? "#54D9FF" : "#B8C7D8"
                            font.pixelSize: 13
                        }

                        MouseArea {
                            id: navMouse
                            anchors.fill: parent
                            hoverEnabled: true
                            cursorShape: Qt.PointingHandCursor
                            onClicked: window.activePage = modelData.key
                        }
                    }
                }

                Item { Layout.fillHeight: true }

                Label { text: "PROTOTYPE"; color: "#6F879F"; font.pixelSize: 10; font.bold: true }
                Label { text: "Live system data: Milestone 2"; color: "#8293A8"; font.pixelSize: 11 }
                Label { text: "ELYTRA OS · x86_64"; color: "#657C94"; font.pixelSize: 10 }
            }
        }

        // Content area
        Item {
            Layout.fillWidth: true
            Layout.fillHeight: true

            // Home view
            ColumnLayout {
                anchors.fill: parent
                visible: window.activePage === "Home"
                spacing: 16

                RowLayout {
                    Layout.fillWidth: true
                    ColumnLayout {
                        spacing: 2
                        Label { text: window.greeting(window.now); color: "#F1F5FA"; font.pixelSize: 29; font.bold: true }
                        Label { text: "Your workspace, your rules."; color: "#8293A8"; font.pixelSize: 13 }
                    }
                    Item { Layout.fillWidth: true }
                    Card {
                        radius: 14
                        color: "#18283A"
                        border.color: "#29445F"
                        implicitWidth: 160
                        implicitHeight: 42
                        RowLayout {
                            anchors.centerIn: parent
                            Label { text: "◷"; color: "#16C9F5"; font.pixelSize: 18 }
                            Label { text: Qt.formatDateTime(window.now, "ddd, dd MMM"); color: "#D9E5F1"; font.pixelSize: 12 }
                        }
                    }
                    Button {
                        text: "⚙"
                        flat: true
                        onClicked: window.activePage = "System Center"
                        contentItem: Text { text: parent.text; color: "#C9D7E6"; font.pixelSize: 20; horizontalAlignment: Text.AlignHCenter }
                    }
                }

                Card {
                    Layout.fillWidth: true
                    Layout.preferredHeight: 180
                    gradient: Gradient {
                        GradientStop { position: 0.0; color: "#E0183552" }
                        GradientStop { position: 0.55; color: "#D9112943" }
                        GradientStop { position: 1.0; color: "#E00C1B30" }
                    }
                    RowLayout {
                        anchors.fill: parent
                        anchors.margins: 24
                        ColumnLayout {
                            Layout.fillWidth: true
                            spacing: 8
                            Label { text: "ELYTRA / AURORA"; color: "#55D9FF"; font.pixelSize: 11; font.bold: true }
                            Label { text: "Make it yours."; color: "#F4F8FC"; font.pixelSize: 30; font.bold: true }
                            Label {
                                text: "A clean, focused space for creating, gaming and managing your world."
                                color: "#B6C9DC"
                                font.pixelSize: 13
                                wrapMode: Text.WordWrap
                                Layout.maximumWidth: 560
                            }
                            Button {
                                text: "Explore workspace  →"
                                onClicked: window.activePage = "Applications"
                                background: Rectangle { radius: 10; color: "#16C9F5" }
                                contentItem: Text { text: parent.text; color: "#06111D"; font.bold: true; padding: 9 }
                            }
                        }
                        Item {
                            Layout.preferredWidth: 190
                            Layout.fillHeight: true
                            Rectangle {
                                anchors.centerIn: parent
                                width: 132; height: 132; radius: 66
                                color: "#1426C9F5"
                                border.color: "#6639D8FF"
                                Rectangle {
                                    anchors.centerIn: parent
                                    width: 84; height: 84; radius: 42
                                    color: "#22267BFF"
                                    border.color: "#AA61DFFF"
                                }
                                Label { anchors.centerIn: parent; text: "E"; color: "#EAFBFF"; font.pixelSize: 55; font.bold: true }
                            }
                        }
                    }
                }

                Label { text: "At a glance"; color: "#F1F5FA"; font.pixelSize: 18; font.bold: true }

                GridLayout {
                    Layout.fillWidth: true
                    columns: width > 850 ? 3 : 2
                    rowSpacing: 14
                    columnSpacing: 14

                    Repeater {
                        model: window.homeTiles
                        delegate: Card {
                            required property var modelData
                            Layout.fillWidth: true
                            Layout.preferredHeight: 142
                            color: "#D9111C2D"

                            ColumnLayout {
                                anchors.fill: parent
                                anchors.margins: 16
                                spacing: 7
                                Label { text: modelData.icon; color: "#35D2FF"; font.pixelSize: 22 }
                                Label { text: modelData.title; color: "#F1F5FA"; font.pixelSize: 15; font.bold: true }
                                Label { text: modelData.desc; color: "#8293A8"; font.pixelSize: 11; Layout.fillWidth: true; wrapMode: Text.WordWrap }
                                Item { Layout.fillHeight: true }
                                Label { text: modelData.cta + "  →"; color: "#42CFF5"; font.pixelSize: 11 }
                            }

                            MouseArea {
                                anchors.fill: parent
                                cursorShape: Qt.PointingHandCursor
                                onClicked: window.activePage = modelData.target
                            }
                        }
                    }
                }

                Item { Layout.fillHeight: true }

                RowLayout {
                    Layout.fillWidth: true
                    Label { text: "ELYTRA is under active development"; color: "#60758D"; font.pixelSize: 10 }
                    Item { Layout.fillWidth: true }
                    Label { text: "AURORA / BUILD 0002"; color: "#60758D"; font.pixelSize: 10 }
                }
            }

            // Section view (all other pages)
            ColumnLayout {
                anchors.fill: parent
                visible: window.activePage !== "Home"
                spacing: 12

                Label { text: window.activePage; color: "#F1F5FA"; font.pixelSize: 29; font.bold: true }
                Label { text: window.currentPage.subtitle; color: "#8293A8"; font.pixelSize: 13; wrapMode: Text.WordWrap; Layout.fillWidth: true }

                Button {
                    text: "←  Back to Home"
                    flat: true
                    onClicked: window.activePage = "Home"
                    contentItem: Text { text: parent.text; color: "#54D9FF"; font.pixelSize: 12; verticalAlignment: Text.AlignVCenter }
                }

                GridLayout {
                    Layout.fillWidth: true
                    columns: width > 850 ? 3 : 2
                    rowSpacing: 14
                    columnSpacing: 14

                    Repeater {
                        model: window.currentPage.items
                        delegate: Card {
                            required property var modelData
                            Layout.fillWidth: true
                            Layout.preferredHeight: 128
                            color: "#D9111C2D"

                            ColumnLayout {
                                anchors.fill: parent
                                anchors.margins: 16
                                spacing: 6
                                RowLayout {
                                    Layout.fillWidth: true
                                    Label { text: modelData.icon; color: "#35D2FF"; font.pixelSize: 20 }
                                    Item { Layout.fillWidth: true }
                                    Rectangle {
                                        radius: 8
                                        color: "#1F3A55"
                                        implicitWidth: statusLbl.implicitWidth + 16
                                        implicitHeight: 22
                                        Label {
                                            id: statusLbl
                                            anchors.centerIn: parent
                                            text: modelData.status
                                            color: "#FFB547"
                                            font.pixelSize: 10
                                        }
                                    }
                                }
                                Label { text: modelData.title; color: "#F1F5FA"; font.pixelSize: 15; font.bold: true }
                                Label { text: modelData.desc; color: "#8293A8"; font.pixelSize: 11; wrapMode: Text.WordWrap; Layout.fillWidth: true }
                                Item { Layout.fillHeight: true }
                            }
                        }
                    }
                }

                Item { Layout.fillHeight: true }
            }
        }
    }
}
