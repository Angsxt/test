#!/usr/bin/env bash
set -euo pipefail
echo "ELYTRA host diagnostics"
echo "----------------------"
printf "Architecture: "; uname -m
printf "Kernel: "; uname -r
printf "OS: "; . /etc/os-release; echo "${PRETTY_NAME:-unknown}"
printf "Desktop: %s\n" "${XDG_CURRENT_DESKTOP:-unknown}"
printf "Session: %s\n" "${XDG_SESSION_TYPE:-unknown}"
if command -v cmake >/dev/null; then cmake --version | head -n1; else echo "CMake: missing"; fi
if command -v qmake6 >/dev/null; then qmake6 -query QT_VERSION; else echo "Qt qmake6: missing/not in PATH"; fi
