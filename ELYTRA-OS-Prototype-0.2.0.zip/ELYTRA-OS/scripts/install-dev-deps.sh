#!/usr/bin/env bash
set -euo pipefail

if [[ "${EUID}" -eq 0 ]]; then
  echo "Bitte ohne sudo starten. Das Skript fragt sudo bei Bedarf selbst ab."
  exit 1
fi

if ! command -v apt-get >/dev/null 2>&1; then
  echo "Dieses Skript unterstützt Ubuntu/Debian mit APT."
  exit 1
fi

sudo apt-get update
sudo apt-get install -y \
  build-essential cmake ninja-build git pkg-config \
  qt6-base-dev qt6-declarative-dev qt6-declarative-dev-tools \
  qml6-module-qtquick qml6-module-qtquick-controls \
  qml6-module-qtquick-layouts qt6-tools-dev

echo
echo "ELYTRA-Entwicklungsabhängigkeiten wurden installiert."
echo "Nächster Schritt: ./scripts/run-dev.sh"
